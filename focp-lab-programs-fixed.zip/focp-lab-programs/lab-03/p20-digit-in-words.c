/*
 * Lab 3.20 - Digit in words (0-9)
 * FOCP Lab 3 (CSE-1003) - B.Tech CSE Semester 1, IIIT Bhopal
 *
 * Sample input: 7
 * Sample output: Seven
 */
#include <stdio.h>

int main() {
    int d;
    printf("Enter a digit (0-9): ");
    scanf("%d", &d);
    switch (d) {
        case 0: printf("Zero"); break;
        case 1: printf("One"); break;
        case 2: printf("Two"); break;
        case 3: printf("Three"); break;
        case 4: printf("Four"); break;
        case 5: printf("Five"); break;
        case 6: printf("Six"); break;
        case 7: printf("Seven"); break;
        case 8: printf("Eight"); break;
        case 9: printf("Nine"); break;
        default: printf("Invalid input. Enter a digit from 0 to 9.");
    }
    return 0;
}
